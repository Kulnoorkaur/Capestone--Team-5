"""Validation and flagging rules for the D2.3 questionnaire.

Implements the handling rules in D2.3 Section 5. The questionnaire never
produces a favourable ("Go") outcome. Its only job is to collect facts,
record gaps and conflicts, and decide whether the profile can be passed to
the D2.6 decision logic or must return "manual regulatory review required".
"""
import re
from .schema import (BY_ID, FIELDS, FRAMEWORKS, UNKNOWN, LOCKED, SITE, ADAPTIVE)

MANUAL_REVIEW = "manual regulatory review required"
STATUS_INCOMPLETE = "Incomplete: gaps recorded; no favourable outcome can be assigned"
STATUS_READY = ("Profile complete: pass to D2.6 decision logic "
                "(this is not a Go outcome and not a compliance finding)")


# ---------- helpers ----------
def _val(answers, fid):
    return (answers.get(fid) or {}).get("value")


def _selected(value):
    """Return a list of selected strings for any answer type."""
    if value is None:
        return []
    if isinstance(value, dict):
        return [v for v in value.values() if v]
    if isinstance(value, (list, tuple, set)):
        return list(value)
    return [value] if str(value).strip() else []


def is_blank(ftype, value):
    if ftype in ("text", "longtext"):
        return not (value or "").strip()
    if ftype == "select":
        return not value
    if ftype == "multiselect":
        return not value
    if ftype == "perframework":
        return not isinstance(value, dict) or any(not value.get(f) for f in FRAMEWORKS)
    return value is None


def is_active(fid, answers):
    """A conditional field is active only when its trigger field is active and matches."""
    f = BY_ID[fid]
    cond = f["when"]
    if not cond:
        return True
    parent = cond["field"]
    if not is_active(parent, answers):
        return False
    return any(v in cond["in"] for v in _selected(_val(answers, parent)))


def needs_details(fid, value):
    f = BY_ID[fid]
    sel = _selected(value)
    return UNKNOWN in sel or any(v in f["detail_on"] for v in sel)


# ---------- validation ----------
def validate(answers):
    """Return a list of {id, problem} for missing or malformed required answers."""
    problems = []
    for f in FIELDS:
        fid = f["id"]
        if not is_active(fid, answers) or not f["required"]:
            continue
        a = answers.get(fid) or {}
        value = a.get("value")
        if is_blank(f["type"], value):
            problems.append({"id": fid, "problem": "Required answer missing"})
            continue
        if f["pattern"] and not re.search(f["pattern"], value or ""):
            problems.append({"id": fid, "problem": f"Expected a reference matching {f['pattern']}"})
        if needs_details(fid, value) and not (a.get("details") or "").strip():
            problems.append({"id": fid, "problem": "Explanation required (Unknown, Other, or detail-triggering answer)"})
        sel = _selected(value) if f["type"] == "multiselect" else []
        exclusive = [v for v in sel if v in ("None", UNKNOWN)]
        if exclusive and len(sel) > 1:
            problems.append({"id": fid, "problem": f"'{exclusive[0]}' cannot be combined with other selections"})
    return problems


# ---------- flags ----------
def _flag(fid, severity, fields, gates, message):
    return {"flag_id": fid, "severity": severity, "fields": fields, "gates": gates, "message": message}


def evaluate(answers):
    """Apply D2.3 Section 5 rules. Severity: blocking | gap | info."""
    flags = []
    v = lambda fid: _val(answers, fid)
    act = lambda fid: is_active(fid, answers)
    sel = lambda fid: _selected(v(fid))

    # 1. Behaviour after release missing/unknown
    b = v("ACC-008")
    if not b or b == UNKNOWN:
        flags.append(_flag("FLG-01", "blocking", ["ACC-008"], "G8",
            "Behaviour after release is missing or Unknown. Do not assume the algorithm is locked."))

    # 2. 'Locked' contradicted by other answers
    if b == LOCKED:
        conflicts = []
        if v("ACC-007") in ("Configurable by site or user", "Adjusted automatically"):
            conflicts.append("ACC-007")
        if [x for x in sel("ACC-009") if x != "None"]:
            conflicts.append("ACC-009")
        if v("ACC-012") == "Yes":
            conflicts.append("ACC-012")
        if conflicts:
            flags.append(_flag("FLG-02", "blocking", ["ACC-008"] + conflicts, "G8",
                "Described as locked, but other answers indicate configurable, field-changing, or "
                "feedback-driven behaviour. Resolve the conflict before using the 'locked' answer."))

    # 3. Adaptive/site-configurable without safeguards or monitoring
    if b in (SITE, ADAPTIVE):
        no_safeguards = (not sel("ACC-011")) or set(sel("ACC-011")) <= {"None", UNKNOWN}
        no_monitor = (not sel("ACC-028")) or set(sel("ACC-028")) <= {"None", UNKNOWN}
        if no_safeguards or no_monitor:
            which = ([] if not no_safeguards else ["ACC-011"]) + ([] if not no_monitor else ["ACC-028"])
            flags.append(_flag("FLG-03", "blocking", ["ACC-008"] + which, "G4; G8; G10",
                "Adaptive or site-configurable behaviour without recorded safeguards, monitoring, or rollback."))

    # 4. Planned changes without a documented change plan
    if v("ACC-013") == "Yes" and act("ACC-019") and v("ACC-019") in ("No", UNKNOWN, None):
        flags.append(_flag("FLG-04", "gap", ["ACC-013", "ACC-019"], "G8; G9",
            "Changes are planned but no documented change plan exists or it is unknown. Do not treat the "
            "changes as pre-authorized, and do not assume no new submission or amendment is needed."))

    # 5. Planned change alters recorded profile
    if act("ACC-017") and v("ACC-017") in ("Yes", "Sometimes"):
        flags.append(_flag("FLG-05", "blocking", ["ACC-017"], "G1; G2; G8",
            "A planned change may alter intended use, population, inputs, outputs, or claims. Assess as a "
            "potential significant/substantial change in each framework separately, and re-complete "
            "D2.1 and D2.2 for the changed product."))

    # 6. Change plan status claimed without supporting document
    if act("ACC-020") and isinstance(v("ACC-020"), dict):
        claimed = [fw for fw, s in v("ACC-020").items() if s == "Authorized or accepted"]
        has_doc = bool((answers.get("ACC-019") or {}).get("details", "").strip()
                       or (answers.get("ACC-020") or {}).get("evidence", "").strip())
        if claimed and not has_doc:
            flags.append(_flag("FLG-06", "blocking", ["ACC-019", "ACC-020"], "G8; G9",
                f"Change plan reported as authorized/accepted ({', '.join(claimed)}) without a supporting "
                "document or correspondence. Treat as unverified."))

    # 7. Third-party components
    if v("ACC-005") == UNKNOWN:
        flags.append(_flag("FLG-07", "gap", ["ACC-005"], "G4; G5; G8",
            "Third-party or pre-trained component status is Unknown. Cross-reference D2.4 and D2.5."))

    # 8. Traceability of output to version/config
    if v("ACC-025") in ("No", "Partly", UNKNOWN):
        flags.append(_flag("FLG-08", "gap", ["ACC-025"], "G8; G10",
            "Algorithm version, training data, and configuration behind an output cannot be fully identified."))

    # 9. Required answers recorded as Unknown (excluding those already flagged blocking above)
    unknown_fields = []
    for f in FIELDS:
        fid = f["id"]
        if fid == "ACC-008" or not act(fid):
            continue
        if UNKNOWN in _selected(v(fid)):
            unknown_fields.append(fid)
    if unknown_fields:
        flags.append(_flag("FLG-09", "gap", unknown_fields, "G8",
            "Required answers recorded as Unknown. Information gaps must be resolved; they are never "
            "treated as a satisfied requirement."))

    # 10. Evidence references
    missing_ev = [f["id"] for f in FIELDS
                  if act(f["id"]) and not is_blank(f["type"], v(f["id"]))
                  and not (answers.get(f["id"]) or {}).get("evidence", "").strip()]
    if missing_ev:
        flags.append(_flag("FLG-10", "gap", missing_ev, "G8; G9",
            "Answers without an evidence reference (document ID, version, page/section). Research sources "
            "justify a field but do not prove a product claim; record as a documentation gap."))

    return flags


def profile_status(problems, flags):
    if any(f["severity"] == "blocking" for f in flags):
        return MANUAL_REVIEW
    if problems or any(f["severity"] == "gap" for f in flags):
        return STATUS_INCOMPLETE
    return STATUS_READY


def build_record(record_name, answers):
    """Assemble the exportable JSON record for one algorithm."""
    problems = validate(answers)
    flags = evaluate(answers)
    out_answers, not_applicable = {}, {}
    for f in FIELDS:
        fid = f["id"]
        if is_active(fid, answers):
            a = answers.get(fid) or {}
            out_answers[fid] = {"value": a.get("value"), "details": a.get("details", ""),
                                "evidence": a.get("evidence", "")}
        else:
            c = f["when"]
            not_applicable[fid] = f"Not applicable: {c['field']} does not trigger this field"
    return {
        "schema_version": "D2.3-draft-1",
        "record_name": record_name,
        "answers": out_answers,
        "not_applicable": not_applicable,
        "validation_problems": problems,
        "flags": flags,
        "profile_status": profile_status(problems, flags),
        "limitations": ("Planning aid only. Not legal or regulatory advice; not a classification, "
                        "compliance finding, or Go outcome. Framework-specific decision logic is D2.6."),
    }
