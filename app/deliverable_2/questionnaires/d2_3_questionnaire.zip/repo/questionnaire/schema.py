"""Field schema for Deliverable 2.3 (ACC-001 .. ACC-029).

This file is the single source of truth for questions, response types,
required/conditional status and gate links. Keep it in sync with the
D2.3 document (Sections 2 and 3). Requirement IDs from D1.6 are NOT stored
here; add them only after verification against the reviewed matrix.
"""

UNKNOWN = "Unknown"
YNU = ["Yes", "No", UNKNOWN]
YPNU = ["Yes", "Partly", "No", UNKNOWN]
FRAMEWORKS = ["Health Canada", "FDA", "EU MDR", "EU AI Act"]
FRAMEWORK_STATUS = [
    "Not submitted", "Planned for submission", "Under review",
    "Authorized or accepted", "Not applicable (give rationale)", UNKNOWN,
]

LOCKED = "Locked (nothing changes in the field; any change is a new released version)"
SITE = "Site-specific configuration only"
ADAPTIVE = "Adaptive (changes in the field through learning)"


def field(fid, group, label, ftype, options=None, required=True, when=None,
          detail_on=None, gates="", pattern=None, help=None):
    """Build a field definition.

    ftype: text | longtext | select | multiselect | perframework
    when: {"field": "ACC-008", "in": [...]} -> field is conditional
    detail_on: values that require an explanation (Unknown always does)
    """
    return {
        "id": fid, "group": group, "label": label, "type": ftype,
        "options": options or [], "required": required, "when": when,
        "detail_on": detail_on or [], "gates": gates, "pattern": pattern,
        "help": help,
    }


G1 = "Algorithm identification and model characteristics"
G2 = "Locked or adaptive behaviour"
G3 = "Planned retraining and updates"
G4 = "Change management and verification"

FIELDS = [
    # ---- 2.1 ----
    field("ACC-001", G1, "Name and version identifier of the algorithm/model release (if different from the product version in PIP-001)", "text", gates="G1; G8"),
    field("ACC-002", G1, "Which AI function(s) from Deliverable 2.2 does this algorithm implement? (list AIF record references, e.g. AIF-004, AIF-006)", "text", pattern=r"AIF-\d{3}", gates="G1; G8"),
    field("ACC-003", G1, "Learning approach or technique", "multiselect",
          ["Supervised", "Semi-/self-supervised", "Unsupervised", "Reinforcement",
           "Rule-based or classical image processing (no learning)",
           "Fine-tuned pre-trained/foundation model", "Generative", "Other (describe)"],
          detail_on=["Other (describe)"], gates="G1/G2; G8"),
    field("ACC-004", G1, "Model architecture family (one model or several?)", "multiselect",
          ["CNN", "Vision transformer", "U-Net/segmentation", "Ensemble/multi-stage",
           "Classical machine learning", "Hybrid", "Other (describe)", UNKNOWN],
          detail_on=["Other (describe)"], gates="G5; G8"),
    field("ACC-005", G1, "Does the algorithm include third-party, pre-trained, or open-source components? (if Yes: component, supplier, version, role)", "select", YNU, detail_on=["Yes"], gates="G4; G5; G8"),
    field("ACC-006", G1, "For the same input and software version, is the output reproducible? (if No: source of variability)", "select", YNU, detail_on=["No"], gates="G5; G8"),
    field("ACC-007", G1, "Are thresholds, operating points, or calibration fixed, or changeable after release? (see AIF-009)", "select",
          ["Fixed", "Changed only by manufacturer release", "Configurable by site or user",
           "Adjusted automatically", UNKNOWN], gates="G5; G8"),
    # ---- 2.2 ----
    field("ACC-008", G2, "How does the algorithm behave after release into clinical use?", "select",
          [LOCKED, SITE, ADAPTIVE, UNKNOWN], gates="G2; G4; G5; G8"),
    field("ACC-009", G2, "Which elements can change without a new manufacturer release?", "multiselect",
          ["Model weights", "Thresholds/operating point", "Pre-/post-processing", "Calibration",
           "Input handling", "None", "Other (describe)", UNKNOWN],
          detail_on=["Other (describe)"], gates="G4; G8"),
    field("ACC-010", G2, "Adaptive mechanism: what triggers learning, what data is used, and who/what approves a change before it takes effect?", "longtext",
          when={"field": "ACC-008", "in": [ADAPTIVE]}, gates="G3; G8"),
    field("ACC-011", G2, "Safeguards on adaptive or site-configurable behaviour", "multiselect",
          ["Limits on size of change", "Performance gate before activation", "Human approval",
           "Automatic rollback", "Audit log", "None", "Other (describe)", UNKNOWN],
          when={"field": "ACC-008", "in": [SITE, ADAPTIVE]},
          detail_on=["Other (describe)"], gates="G4; G8; G10"),
    field("ACC-012", G2, "Can user corrections, site data, or clinical outcomes be fed back into training or tuning? (if Yes: data path and screening)", "select", YNU, detail_on=["Yes"], gates="G3; G4; G8"),
    # ---- 2.3 ----
    field("ACC-013", G3, "Are retraining, model updates, or other algorithm changes planned or anticipated during the lifecycle?", "select", YNU, gates="G8"),
    field("ACC-014", G3, "Which types of change are planned?", "multiselect",
          ["Retraining on additional data of the same kind", "Expanded or new training data",
           "Architecture change", "Threshold/operating-point change",
           "New scanners, vendors, or protocols", "Wider patient population",
           "New indication or intended use", "New output type", "Performance improvement",
           "Bug fix", "Cybersecurity patch", "Other (describe)"],
          when={"field": "ACC-013", "in": ["Yes", UNKNOWN]}, detail_on=["Other (describe)"], gates="G2; G8"),
    field("ACC-015", G3, "How often are changes expected, and what triggers them?", "select",
          ["Scheduled", "Performance-triggered", "Event-driven", "Ad hoc", UNKNOWN],
          when={"field": "ACC-013", "in": ["Yes", UNKNOWN]}, gates="G8; G10"),
    field("ACC-016", G3, "Describe each planned modification: what will change, the limits, and the expected effect on performance (one entry per modification)", "longtext",
          when={"field": "ACC-013", "in": ["Yes"]}, gates="G8; G9"),
    field("ACC-017", G3, "Would any planned change alter the intended use, indications, users, population, inputs, outputs, or performance claims recorded in D2.1/D2.2? (list affected PIP/AIF IDs)", "select",
          ["Yes", "No", "Sometimes", UNKNOWN],
          when={"field": "ACC-013", "in": ["Yes", UNKNOWN]}, detail_on=["Yes", "Sometimes"], gates="G1; G2; G8"),
    field("ACC-018", G3, "Will retraining use data that differs from the original in source, site, device vendor, or population? (if Yes: reference the D2.4 dataset record)", "select", YNU,
          when={"field": "ACC-013", "in": ["Yes"]}, detail_on=["Yes"], gates="G3; G8"),
    field("ACC-019", G3, "Is there a documented plan that pre-specifies the planned modifications and how each is verified (PCCP or equivalent)? (give document and framework)", "select", YPNU,
          when={"field": "ACC-013", "in": ["Yes"]}, detail_on=["Yes", "Partly"], gates="G8; G9"),
    field("ACC-020", G3, "Regulatory status of the change plan in each framework", "perframework", FRAMEWORK_STATUS,
          when={"field": "ACC-019", "in": ["Yes", "Partly", UNKNOWN]}, detail_on=["Not applicable (give rationale)"], gates="G8; G9"),
    # ---- 2.4 ----
    field("ACC-021", G4, "Is there a documented procedure for controlling software and algorithm changes within the QMS? (procedure ID and version)", "select", YPNU, detail_on=["Yes", "Partly"], gates="G8; G9"),
    field("ACC-022", G4, "How is each change assessed for regulatory significance? (criteria, who decides, how recorded)", "longtext", gates="G2; G8"),
    field("ACC-023", G4, "What verification and validation is performed before a change is released? (test data, regression testing, subgroup checks)", "longtext", gates="G5; G8"),
    field("ACC-024", G4, "Are acceptance criteria for releasing a change defined in advance? (describe)", "select", YPNU, detail_on=["Yes", "Partly"], gates="G5; G8"),
    field("ACC-025", G4, "Can the exact algorithm version, training-data version, and configuration behind any output be identified? (describe how)", "select", YPNU, detail_on=["Yes", "Partly"], gates="G8; G10"),
    field("ACC-026", G4, "How are updates delivered to deployed installations?", "multiselect",
          ["Automatic remote update", "Remote update with site/user approval", "Installed by manufacturer",
           "Installed by user", "Cloud-side change with no user action", "Other (describe)", UNKNOWN],
          detail_on=["Other (describe)"], gates="G7; G8"),
    field("ACC-027", G4, "How are users informed when the algorithm changes?", "multiselect",
          ["Release notes", "Labeling/IFU update", "In-product notice", "User training",
           "Notice of performance change", "None", UNKNOWN], gates="G7; G8"),
    field("ACC-028", G4, "How is performance monitored after an update, and can a previous version be restored?", "multiselect",
          ["Performance monitoring", "Drift detection", "User feedback channel",
           "Rollback to prior version", "None", "Other (describe)", UNKNOWN],
          detail_on=["Other (describe)"], gates="G8; G10"),
    field("ACC-029", G4, "Changes made since the last regulatory authorization or first release", "select",
          ["Changes have been made since last release", "None", "Not applicable (not previously released)"],
          detail_on=["Changes have been made since last release", "Not applicable (not previously released)"],
          help="For changes, list: version; date; description; regulatory assessment; outcome.", gates="G8; G9"),
]

BY_ID = {f["id"]: f for f in FIELDS}
GROUPS = [G1, G2, G3, G4]
