from pathlib import Path
from streamlit.testing.v1 import AppTest

APP = str(Path(__file__).resolve().parent.parent / "app.py")


def test_app_loads_and_flags_missing_behaviour():
    at = AppTest.from_file(APP, default_timeout=30).run()
    assert not at.exception
    assert "manual regulatory review required" in " ".join(e.value for e in at.error)


def test_preseeded_locked_answer_removes_flag_01():
    # Seeds widget state directly: AppTest's selectbox.select() is unreliable with index=None widgets.
    from questionnaire.schema import LOCKED
    at = AppTest.from_file(APP, default_timeout=30)
    at.session_state["0|ACC-008|v"] = LOCKED
    at.run()
    assert not at.exception
    text = " ".join(m.value for m in at.markdown)
    assert "FLG-01" not in text
